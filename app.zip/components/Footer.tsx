import Link from "next/link";
import { HiSparkles } from "react-icons/hi2";

const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Features", href: "/#features" },
  { label: "Pricing", href: "/#pricing" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

const LEGAL_LINKS = [
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Terms", href: "/terms" },
];

export default function Footer() {
  return (
    <footer className="border-t border-border-soft/70 bg-cream-deep/60">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="flex flex-col items-center gap-6 text-center sm:flex-row sm:items-start sm:justify-between sm:text-left">
          <div>
            <Link href="/" className="flex items-center justify-center gap-2 sm:justify-start">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-cream">
                <HiSparkles size={15} />
              </span>
              <span className="font-heading text-base font-extrabold tracking-tight text-ink">
                LikhoAI
              </span>
            </Link>
            <p className="mt-2 text-sm text-ink-soft">Made with ❤️ in Pakistan</p>
          </div>

          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 sm:justify-start">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-sm font-medium text-ink-soft transition-colors hover:text-ink"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="mt-10 flex flex-col items-center gap-3 border-t border-border-soft/70 pt-6 text-xs text-muted sm:flex-row sm:justify-between">
          <div className="flex items-center gap-4">
            {LEGAL_LINKS.map((link) => (
              <Link key={link.label} href={link.href} className="hover:text-ink-soft">
                {link.label}
              </Link>
            ))}
          </div>
          <p>© {new Date().getFullYear()} LikhoAI</p>
        </div>
      </div>
    </footer>
  );
}
