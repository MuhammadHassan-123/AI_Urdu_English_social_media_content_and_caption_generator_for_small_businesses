"use client";

import {
  HistoryItem,
  removeHistory,
  clearHistory,
} from "@/lib/history";

import {
  HiOutlineClock,
  HiOutlineTrash,
} from "react-icons/hi2";

type Props = {
  history: HistoryItem[];
  onView: (item: HistoryItem) => void;
  onRefresh: () => void;
};

export default function HistorySection({
  history,
  onView,
  onRefresh,
}: Props) {
  if (history.length === 0) return null;

  async function deleteItem(id: string) {
   await removeHistory(id);
   await onRefresh();
  }

  async function deleteAll() {
    const ok = confirm("Are you sure you want to clear all history?");

    if (!ok) return;

    await clearHistory();
    await onRefresh();
  }

  return (
    <section className="mx-auto mt-12 max-w-5xl px-5">

      {/* Header */}
      <div className="mb-6 flex items-center justify-between">

        <h2 className="flex items-center gap-2 text-2xl font-bold">
          <HiOutlineClock />
          Recent History
        </h2>

        <button
          onClick={deleteAll}
          className="rounded-lg bg-red-500 px-4 py-2 text-sm font-medium text-white hover:bg-red-600"
        >
          🗑 Clear All
        </button>

      </div>

      {/* History Cards */}
      <div className="space-y-4">

        {history.map((item) => (
          <div
            key={item.id}
            className="rounded-xl border bg-white p-5 shadow-sm"
          >
            <div className="flex items-center justify-between">

              <div>

                <h3 className="font-semibold">
                  {item.businessType}
                </h3>

                <p className="text-sm text-gray-500">
                  {item.product}
                </p>

                <p className="text-sm text-gray-500">
                 {item.createdAt?.toDate().toLocaleString()}
                </p>

              </div>

              <div className="flex gap-3">

                <button
                  onClick={() => onView(item)}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm text-white hover:bg-indigo-700"
                >
                  View
                </button>

                <button
                  onClick={() => deleteItem(item.id)}
                  className="rounded-lg bg-red-500 px-4 py-2 text-sm text-white hover:bg-red-600"
                >
                  <HiOutlineTrash size={18} />
                </button>

              </div>

            </div>
          </div>
        ))}

      </div>

    </section>
  );
}