"use client";

import { useEffect, useState } from "react";
import { auth, db } from "@/lib/firebase";
import { doc, getDoc } from "firebase/firestore";
import Link from "next/link";

type UserPlan = {
  plan: string;
  dailyLimit: number;
  generationsToday: number;
};

export default function UsageCard() {
  const [userPlan, setUserPlan] = useState<UserPlan | null>(null);

  useEffect(() => {
    async function loadData() {
      const user = auth.currentUser;

      if (!user) return;

      const snap = await getDoc(doc(db, "users", user.uid));

      if (snap.exists()) {
        setUserPlan(snap.data() as UserPlan);
      }
    }

    loadData();
  }, []);

  if (!userPlan) return null;

  const remaining =
    userPlan.plan === "premium"
      ? "Unlimited"
      : userPlan.dailyLimit - userPlan.generationsToday;

  const percentage =
    userPlan.plan === "premium"
      ? 100
      : (userPlan.generationsToday / userPlan.dailyLimit) * 100;

  return (
    <div className="rounded-2xl border bg-white p-6 shadow-sm">
      <h3 className="text-xl font-bold">
        {userPlan.plan === "premium" ? "Premium Plan" : "Free Plan"}
      </h3>

      <p className="mt-3 text-gray-600">
        Remaining Today
      </p>

      <p className="mt-1 text-3xl font-bold text-brand-600">
        {remaining}
      </p>

      {userPlan.plan !== "premium" && (
        <>
          <div className="mt-4 h-3 overflow-hidden rounded-full bg-gray-200">
            <div
              className="h-full rounded-full bg-brand-600"
              style={{
                width: `${percentage}%`,
              }}
            />
          </div>

          <p className="mt-2 text-sm text-gray-500">
            {userPlan.generationsToday} of {userPlan.dailyLimit} used today
          </p>

          <Link
            href="/pricing"
            className="mt-5 inline-block rounded-full bg-brand-600 px-5 py-2 text-sm font-semibold text-white hover:bg-brand-700"
          >
            Upgrade to Premium
          </Link>
        </>
      )}
    </div>
  );
}