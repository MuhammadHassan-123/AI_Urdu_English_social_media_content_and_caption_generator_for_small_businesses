import { HiOutlineCheck } from "react-icons/hi2";

const plans = [
  {
    name: "Free",
    price: "Rs. 0",
    description: "Perfect for trying LikhoAI.",
    featured: false,
    button: "Start Free",

    features: [
      "20 AI generations per day",
      "English, Urdu & Roman Urdu",
      "Caption Generator",
      "Hashtag Generator",
      "Reel Ideas",
      "Story Ideas",
      "Image Prompt Generator",
      "Generation History",
      "Favorite Captions",
    ],
  },

  {
    name: "Pro",
    price: "Rs. 299 / month",
    description:
      "Built for Pakistani small businesses and content creators.",
    featured: true,
    button: "Upgrade to Pro",

    features: [
      "Unlimited AI generations",
      "Priority AI responses",
      "Unlimited History",
      "Unlimited Favorites",
      "Export TXT",
      "Future Brand Voice",
      "Future AI Scheduler",
      "Future Analytics Dashboard",
      "Priority Support",
    ],
  },
];

export default function Pricing() {
  return (
    <section
      id="pricing"
      className="bg-gray-50 py-24"
    >
      <div className="mx-auto max-w-6xl px-5">

        <div className="text-center">

          <h2 className="text-4xl font-bold">
            Simple Pricing
          </h2>

          <p className="mt-4 text-gray-600">
            Start for free. Upgrade only when your business grows.
          </p>

        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-2">

          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`rounded-2xl border bg-white p-8 shadow-sm transition hover:-translate-y-2 hover:shadow-xl ${
                plan.featured
                  ? "border-brand-600 ring-2 ring-brand-100"
                  : ""
              }`}
            >

              {plan.featured && (
                <span className="rounded-full bg-brand-600 px-3 py-1 text-xs font-semibold text-white">
                  Recommended
                </span>
              )}

              <h3 className="mt-4 text-3xl font-bold">
                {plan.name}
              </h3>

              <p className="mt-3 text-5xl font-extrabold text-brand-600">
                {plan.price}
              </p>

              <p className="mt-4 text-gray-600">
                {plan.description}
              </p>

              <ul className="mt-8 space-y-4">

                {plan.features.map((feature) => (
                  <li
                    key={feature}
                    className="flex items-center gap-3"
                  >
                    <HiOutlineCheck className="text-green-600" />
                    <span>{feature}</span>
                  </li>
                ))}

              </ul>

              <button
                className={`mt-10 w-full rounded-xl py-3 font-semibold transition ${
                  plan.featured
                    ? "bg-brand-600 text-white hover:bg-brand-700"
                    : "border border-brand-600 text-brand-600 hover:bg-brand-50"
                }`}
              >
                {plan.button}
              </button>

            </div>
          ))}

        </div>

      </div>
    </section>
  );
}