import {
  HiOutlinePencilSquare,
  HiOutlineSparkles,
  HiOutlineClipboardDocument,
} from "react-icons/hi2";

const steps = [
  {
    icon: HiOutlinePencilSquare,
    title: "1. Enter Your Business Details",
    description:
      "Select your business type, product, platform, language and tone.",
  },
  {
    icon: HiOutlineSparkles,
    title: "2. AI Generates Content",
    description:
      "LikhoAI creates 5 unique captions, hashtags, reel ideas, story ideas and image prompts in seconds.",
  },
  {
    icon: HiOutlineClipboardDocument,
    title: "3. Copy & Share",
    description:
      "Copy your favorite caption, export it, or save it for later with one click.",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-24 bg-white">
      <div className="mx-auto max-w-6xl px-5">

        <div className="text-center">
          <h2 className="text-4xl font-bold">
            How It Works
          </h2>

          <p className="mt-4 text-gray-600">
            Create professional social media content in three easy steps.
          </p>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-3">

          {steps.map((step) => {

            const Icon = step.icon;

            return (
              <div
                key={step.title}
                className="rounded-2xl border bg-white p-8 shadow-sm transition hover:-translate-y-2 hover:shadow-xl"
              >
                <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-brand-100 text-brand-600">
                  <Icon size={28} />
                </div>

                <h3 className="text-xl font-bold">
                  {step.title}
                </h3>

                <p className="mt-3 text-gray-600 leading-7">
                  {step.description}
                </p>
              </div>
            );

          })}

        </div>

      </div>
    </section>
  );
}