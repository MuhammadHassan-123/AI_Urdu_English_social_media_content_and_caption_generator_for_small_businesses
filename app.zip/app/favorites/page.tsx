"use client";

import { useEffect, useState } from "react";

import Link from "next/link";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

import {
  FavoriteItem,
  getFavorites,
  removeFavorite,
} from "@/lib/favorites";

import {
  HiOutlineTrash,
  HiOutlineArrowLeft,
} from "react-icons/hi2";

import toast from "react-hot-toast";

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const [loading, setLoading] = useState(true);

  async function loadFavorites() {
    setLoading(true);

    const data = await getFavorites();

    setFavorites(data);

    setLoading(false);
  }

  useEffect(() => {
  (async () => {
    await loadFavorites();
  })();
}, []);

  async function deleteFavorite(id: string) {
    await removeFavorite(id);

    toast.success("Favorite removed.");

    loadFavorites();
  }

  return (
    <>
      <Navbar />

      <main className="mx-auto max-w-6xl px-5 py-14">

        <div className="mb-10 flex items-center justify-between">

          <div>

            <h1 className="text-3xl font-bold text-ink">
              ❤️ Favorite Captions
            </h1>

            <p className="mt-2 text-ink-soft">
              Your saved captions.
            </p>

          </div>

          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-full border px-5 py-2.5 text-sm font-semibold hover:bg-gray-50"
          >
            <HiOutlineArrowLeft />
            Back
          </Link>

        </div>

        {loading && (
          <p className="text-center text-gray-500">
            Loading...
          </p>
        )}

        {!loading && favorites.length === 0 && (
          <div className="rounded-xl border bg-white p-12 text-center">

            <h2 className="text-xl font-semibold">
              No favorites yet
            </h2>

            <p className="mt-2 text-gray-500">
              Save captions by clicking the ❤️ icon.
            </p>

          </div>
        )}

        <div className="space-y-6">

          {favorites.map((item) => (

            <div
              key={item.id}
              className="rounded-xl border bg-white p-6 shadow-sm"
            >

              {/* Header */}

              <div className="mb-4 flex items-center justify-between">

                <div>

                  <h3 className="text-lg font-bold text-brand-600">
                    {item.businessType}
                  </h3>

                  <p className="text-sm text-gray-500">
                    {item.product}
                  </p>

                </div>

                <button
                  onClick={() => deleteFavorite(item.id)}
                  className="rounded-full p-2 hover:bg-red-50"
                >
                  <HiOutlineTrash
                    className="text-red-500"
                    size={20}
                  />
                </button>

              </div>

              {/* Saved Caption */}

              <div className="rounded-lg border p-4">

                <p className="font-semibold text-brand-600">
                  Saved Caption
                </p>

                <p className="mt-3">
                  {item.result.captions[0].english}
                </p>

                <p className="mt-4 text-right font-urdu text-lg">
                  {item.result.captions[0].urdu}
                </p>

                <p className="mt-4">
                  {item.result.captions[0].romanUrdu}
                </p>

              </div>

              {/* Hashtags */}

              <div className="mt-6">

                <h4 className="font-semibold text-brand-600 mb-2">
                  Hashtags
                </h4>

                <div className="flex flex-wrap gap-2">

                  {item.result.hashtags.map((tag, index) => (
                    <span
                      key={index}
                      className="rounded-full bg-brand-100 px-3 py-1 text-sm text-brand-700"
                    >
                      {tag}
                    </span>
                  ))}

                </div>

              </div>

              {/* Reel Idea */}

              <div className="mt-6 rounded-lg border p-4">

                <h4 className="font-semibold text-brand-600">
                  🎬 Reel Idea
                </h4>

                <p className="mt-2">
                  {item.result.reelIdea}
                </p>

              </div>

              {/* Story Idea */}

              <div className="mt-6 rounded-lg border p-4">

                <h4 className="font-semibold text-brand-600">
                  📖 Story Idea
                </h4>

                <p className="mt-2">
                  {item.result.storyIdea}
                </p>

              </div>

              {/* Image Prompt */}

              <div className="mt-6 rounded-lg border p-4">

                <h4 className="font-semibold text-brand-600">
                  🖼 Image Prompt
                </h4>

                <p className="mt-2">
                  {item.result.imagePrompt}
                </p>

              </div>

            </div>

          ))}

        </div>

      </main>

      <Footer />
    </>
  );
}