import type { Metadata } from "next";
import Link from "next/link";
import {
  HiOutlineFlag,
  HiOutlineSparkles,
  HiOutlineUserGroup,
  HiOutlineMapPin,
  HiOutlineCpuChip,
  HiOutlineChatBubbleLeftRight,
} from "react-icons/hi2";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "About",
  description:
    "LikhoAI helps Pakistani small businesses generate ready-to-post Urdu, Roman Urdu, and English social media content in one click, powered by Google Gemini.",
};

const SECTIONS = [
  {
    icon: HiOutlineFlag,
    title: "Our Mission",
    body: "Small Pakistani businesses — kirana stores, home bakers, tailors, tuition centers — don't have time to write social media content every single day, in two languages, on top of running the business itself. LikhoAI exists to give that time back, so posting stays consistent without eating up an owner's evening.",
  },
  {
    icon: HiOutlineSparkles,
    title: "Why LikhoAI?",
    body: "Most AI writing tools are built for English-first, Western markets. They miss local flavor entirely — the natural code-switching between Urdu script, Roman Urdu, and English that real Pakistani businesses actually post in. LikhoAI is built around that mix from the ground up, not bolted on as an afterthought.",
  },
  {
    icon: HiOutlineUserGroup,
    title: "Who is it for?",
    body: "Shop owners, home-based sellers, local influencers, tutors, and clinics who post on Facebook, Instagram, TikTok, or WhatsApp Status — and want captions, hashtags, and content ideas ready in seconds instead of hours.",
  },
  {
    icon: HiOutlineMapPin,
    title: "Built for Pakistani businesses",
    body: "From Eid sales to Ramzan promotions, from price-sensitive customers to WhatsApp Status as a primary marketing channel — LikhoAI understands the context that generic tools don't, because it was designed around it from day one.",
  },
  {
    icon: HiOutlineCpuChip,
    title: "AI Powered by Gemini",
    body: "LikhoAI runs on Google's Gemini model, chosen for its strength in multilingual and creative writing. It's fast, understands nuance across English and Urdu, and keeps getting better — but we always recommend a quick human check on prices, dates, and facts before you post.",
  },
];

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="bg-cream">
        {/* Header */}
        <section className="bg-gradient-to-br from-brand-50 via-cream to-peach px-5 pb-16 pt-16 text-center sm:pt-20">
          <span className="mb-5 inline-flex items-center gap-2 rounded-full bg-brand-100 px-4 py-1.5 text-xs font-semibold text-brand-700">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-600" />
            About LikhoAI
          </span>
          <h1 className="mx-auto max-w-2xl font-heading text-3xl font-extrabold leading-tight tracking-tight text-ink sm:text-4xl">
            Helping Pakistani businesses show up online, every single day.
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-ink-soft">
            LikhoAI is a small tool built for a very specific, very real problem — one shared by
            thousands of shop owners, home sellers, and small teams across Pakistan.
          </p>
        </section>

        {/* Sections grid */}
        <section className="mx-auto max-w-5xl px-5 py-16">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            {SECTIONS.map((section) => (
              <div
                key={section.title}
                className="rounded-card border border-border-soft/80 bg-white p-6 shadow-sm shadow-ink/5 sm:p-7"
              >
                <span className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-brand-50 text-brand-600">
                  <section.icon size={20} />
                </span>
                <h2 className="font-heading text-lg font-bold text-ink">{section.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-ink-soft">{section.body}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 py-16">
  <h2 className="mb-8 text-center font-heading text-2xl font-bold">
    Who We Help
  </h2>

  <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
    {[
      "🏪 Kirana Stores",
      "🍰 Home Bakers",
      "💄 Beauty Parlors",
      "👗 Boutiques",
      "🍽 Restaurants",
      "📱 Mobile Shops",
      "🏥 Clinics",
      "📚 Tuition Centers",
      "🛋 Home Decor",
      "🚀 Startups",
    ].map((item) => (
      <div
        key={item}
        className="rounded-card border border-border-soft bg-white p-4 text-center shadow-sm"
      >
        {item}
      </div>
    ))}
  </div>
</section>

<section className="mx-auto max-w-4xl px-5 py-16 text-center">
  <h2 className="font-heading text-3xl font-bold">
    Our Vision
  </h2>

  <p className="mt-5 text-ink-soft leading-8">
    To become Pakistan&apos;s most trusted AI assistant for social media content,
    helping every small business create professional marketing content in
    English, Urdu and Roman Urdu within seconds.
  </p>
</section>

        {/* Contact CTA */}
        <section className="px-5 pb-20">
          <div className="mx-auto flex max-w-3xl flex-col items-center gap-5 rounded-card border border-border-soft/80 bg-gradient-to-br from-brand-50 via-cream to-peach p-10 text-center shadow-sm shadow-ink/5">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-600 text-cream">
              <HiOutlineChatBubbleLeftRight size={20} />
            </span>
            <h2 className="font-heading text-2xl font-extrabold tracking-tight text-ink">
              Have a question or feedback?
            </h2>
            <p className="max-w-md text-sm text-ink-soft">
              We&apos;d love to hear from you — whether it&apos;s a bug, a business type we
              haven&apos;t covered yet, or just a hello.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 rounded-full bg-brand-600 px-6 py-3 text-sm font-semibold text-cream shadow-md shadow-brand-700/25 transition-transform hover:scale-[1.03] hover:bg-brand-700"
            >
              Contact us
            </Link>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 py-8">
  <h2 className="mb-8 text-center font-heading text-2xl font-bold text-ink">
    Built With
  </h2>

  <div className="flex flex-wrap justify-center gap-4">
    {[
      "Next.js",
      "TypeScript",
      "Tailwind CSS",
      "Gemini AI",
      "Google AI Studio",
      "Vercel",
    ].map((tech) => (
      <span
        key={tech}
        className="rounded-full border border-border-soft bg-white px-5 py-2 text-sm font-medium shadow-sm"
      >
        {tech}
      </span>
    ))}
  </div>
</section>


      </main>
      <Footer />
    </>
  );
}
