"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import UsageCard from "@/components/UsageCard";
import { useAuth } from "@/components/AuthProvider";
import ProtectedRoute from "@/components/ProtectedRoute";
import Navbar from "@/components/Navbar";

export default function DashboardPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/login");
    }
  }, [loading, user, router]);

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <p className="text-lg font-medium">Loading...</p>
      </main>
    );
  }

  if (!user) return null;

   return (
    <ProtectedRoute>
      <Navbar />
      <UsageCard />
      <main className="mx-auto max-w-6xl px-6 py-12">

        <h1 className="text-3xl font-bold">
          Welcome 👋
        </h1>

        <p className="mt-3 text-gray-600">
          {user?.displayName || user?.email}
        </p>

      </main>
    </ProtectedRoute>
  );
}