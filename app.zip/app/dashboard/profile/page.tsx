"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { db } from "@/lib/firebase";

import {
  doc,
  getDoc,
  updateDoc,
} from "firebase/firestore";

import toast from "react-hot-toast";

export default function ProfilePage() {
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [businessName, setBusinessName] = useState("");
  const [businessCategory, setBusinessCategory] = useState("");
  const [businessDescription, setBusinessDescription] = useState("");

  const [defaultTone, setDefaultTone] = useState("Friendly");
  const [defaultLanguage, setDefaultLanguage] = useState("Urdu");
  const [defaultPlatform, setDefaultPlatform] = useState("Facebook");

  useEffect(() => {
    async function loadProfile() {
      if (!user) return;

      const snap = await getDoc(doc(db, "users", user.uid));

      if (snap.exists()) {
        const data = snap.data();

        setBusinessName(data.businessName || "");
        setBusinessCategory(data.businessCategory || "");
        setBusinessDescription(data.businessDescription || "");

        setDefaultTone(data.defaultTone || "Friendly");
        setDefaultLanguage(data.defaultLanguage || "Urdu");
        setDefaultPlatform(data.defaultPlatform || "Facebook");
      }

      setLoading(false);
    }

    loadProfile();
  }, [user]);

  async function saveProfile() {
    if (!user) return;

    setSaving(true);

    try {
      await updateDoc(doc(db, "users", user.uid), {
        businessName,
        businessCategory,
        businessDescription,
        defaultTone,
        defaultLanguage,
        defaultPlatform,
      });

      toast.success("Business profile updated!");
    } catch {
      toast.error("Failed to update profile.");
    }

    setSaving(false);
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl py-20 text-center">
        Loading profile...
      </div>
    );
  }

  return (
    <main className="mx-auto max-w-3xl px-5 py-16">

      <h1 className="text-4xl font-bold">
        Business Profile
      </h1>

      <p className="mt-2 text-gray-500">
        Configure your default business settings.
      </p>

      <div className="mt-10 space-y-6">

        <div>
          <label className="mb-2 block font-semibold">
            Business Name
          </label>

          <input
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            className="w-full rounded-xl border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-semibold">
            Business Category
          </label>

          <input
            value={businessCategory}
            onChange={(e) => setBusinessCategory(e.target.value)}
            className="w-full rounded-xl border p-3"
            placeholder="Bakery, Clothing, Restaurant..."
          />
        </div>

        <div>
          <label className="mb-2 block font-semibold">
            Business Description
          </label>

          <textarea
            rows={4}
            value={businessDescription}
            onChange={(e) => setBusinessDescription(e.target.value)}
            className="w-full rounded-xl border p-3"
          />
        </div>

        <div>
          <label className="mb-2 block font-semibold">
            Default Tone
          </label>

          <select
            value={defaultTone}
            onChange={(e) => setDefaultTone(e.target.value)}
            className="w-full rounded-xl border p-3"
          >
            <option>Friendly</option>
            <option>Professional</option>
            <option>Luxury</option>
            <option>Funny</option>
            <option>Emotional</option>
          </select>
        </div>

        <div>
          <label className="mb-2 block font-semibold">
            Default Language
          </label>

          <select
            value={defaultLanguage}
            onChange={(e) => setDefaultLanguage(e.target.value)}
            className="w-full rounded-xl border p-3"
          >
            <option>Urdu</option>
            <option>English</option>
            <option>Roman Urdu</option>
            <option>Mixed</option>
          </select>
        </div>

        <div>
          <label className="mb-2 block font-semibold">
            Default Platform
          </label>

          <select
            value={defaultPlatform}
            onChange={(e) => setDefaultPlatform(e.target.value)}
            className="w-full rounded-xl border p-3"
          >
            <option>Facebook</option>
            <option>Instagram</option>
            <option>LinkedIn</option>
            <option>WhatsApp</option>
          </select>
        </div>

        <button
          onClick={saveProfile}
          disabled={saving}
          className="w-full rounded-xl bg-brand-600 py-3 font-semibold text-white hover:bg-brand-700 disabled:opacity-50"
        >
          {saving ? "Saving..." : "Save Changes"}
        </button>

      </div>
    </main>
  );
}